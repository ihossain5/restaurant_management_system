<h1>Here is your login credentials</h1>
   

 <p>Email : {{$email}}</p>
 <p>password : {{$password}}</p>

 <p>You can change your password after login.</p>
 <p>Thank you</p>