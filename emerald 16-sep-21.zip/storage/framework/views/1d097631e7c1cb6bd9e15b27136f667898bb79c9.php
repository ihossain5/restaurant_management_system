<footer class="footer">
    <!-- © 2021 - Crafted with <i class="mdi mdi-heart text-danger"></i> by Antopolis. -->
</footer><?php /**PATH C:\xampp\htdocs\fonik_master_new\resources\views/layouts/admin/footer.blade.php ENDPATH**/ ?>