       <!-- Top Bar Start -->
       <div class="topbar">
    
        <nav class="navbar-custom">
            <!-- Search input -->
            

            <ul class="list-inline float-right mb-0">
                <!-- Search -->
                
                <!-- Fullscreen -->
                
                <!-- notification-->
                
                <!-- User-->
                <li class="list-inline-item dropdown notification-list">
                    <a class="nav-link dropdown-toggle arrow-none waves-effect nav-user" data-toggle="dropdown" href="#" role="button"
                       aria-haspopup="false" aria-expanded="false">
                       <?php if(Auth::user()->image != null): ?>
                        <img src="<?php echo e(asset('images/'.Auth::user()->image)); ?>" alt="user" class="rounded-circle">
                        <?php else: ?> 
                        <img src="<?php echo e(asset('images/default.png')); ?>" alt="user" class="rounded-circle">
                       <?php endif; ?>
                        
                    </a>
                    <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                        <a class="dropdown-item" href="<?php echo e(route('user.profile')); ?>"><i class="dripicons-user text-muted"></i> Profile</a>
                        
                        
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="dripicons-exit text-muted"></i> Logout</a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
            </ul>

            <!-- Page title -->
            <ul class="list-inline menu-left mb-0">
                <li class="list-inline-item">
                    <button type="button" class="button-menu-mobile open-left waves-effect">
                        <i class="ion-navicon"></i>
                    </button>
                </li>
                <li class="hide-phone list-inline-item app-search">
                    <h3 class="page-title">Dashboard</h3>
                </li>
            </ul>

            <div class="clearfix"></div>
        </nav>

    </div>
    <!-- Top Bar End --><?php /**PATH C:\xampp\htdocs\fonik_master_new\resources\views/layouts/admin/top_bar.blade.php ENDPATH**/ ?>