
<?php $__env->startSection('pageCss'); ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
        rel="stylesheet">

    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">



    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
        integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="<?php echo e(asset('backend/style.css')); ?>">
    <style>
        .item_plus_icon {
            font-size: 25px;
            margin-top: 0px;
            cursor: pointer;
            position: fixed;
            margin-left: 40px;
        }

        .edit_item_plus_icon {
            font-size: 25px;
            margin-top: 0px;
            cursor: pointer;
            position: fixed;
            margin-left: 40px;
        }

        .close_btn {
            margin: 28px 20px;
            position: relative;
            color: #a72d2d;
            font-size: 25px;
            cursor: pointer;
        }

        #unit_price_div {
            margin: -22px 0px;
        }

        .disabled {
            pointer-events: none;
            cursor: not-allowed;
            box-shadow: none;
            /* opacity: 0.65;
                                                                        filter: alpha(opacity=65);
                                                                        -webkit-box-shadow: none; */
        }

        .fa-check {
            font-size: 18px;
            color: #ffffff;
            /* margin-right: 5px; */
        }

        .invoice_modal-lg {
            max-width: 630px !important;
        }

        .view_modal_close_icon {
            margin: -90px -15px !important;
        }
        .modal {
  overflow-y:auto;
}

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="preloader">

    </div>

    <div class="page-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <div class="d-flex justify-content-between mb-4">
                                <div class="ms-header-text">
                                    <h4 class="mt-0 header-title">All Invoices</h4>
                                </div>
                                <?php if(Auth::user()->email == 'sheehanvy@gmail.com' || Auth::user()->is_admin == 1 || Auth::user()->is_admin == 0): ?>
                                    <button type="button"
                                        class="btn btn-outline-purple float-right waves-effect waves-light" name="button"
                                        id="addButton" data-toggle="modal" data-target="#add"> Add
                                        New
                                    </button>
                                <?php endif; ?>

                            </div>

                            <span class="showError"></span>
                            <div class="table-responsive">
                                <table id="invoiceTable" class="table table-bordered dt-responsive nowrap"
                                    style="border-collapse: collapse; border-spacing: 0;">
                                    <thead>
                                        <tr>
                                            <th style="width: 13%">ID</th>
                                            <th style="width: 13%">Date</th>
                                            <th style="width: 13%">Status</th>
                                            <th style="width: 13%">Client</th>
                                            <th style="width: 13%">Items</th>
                                            <th style="width: 13%">Grand Total</th>
                                            
                                            <th style="width: 22%">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(!empty($invoices)): ?>
                                            <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(Auth::user()->email == 'sheehanvy@gmail.com' || Auth::user()->is_admin == 1): ?>
                                                    <tr class="invoice<?php echo e($invoice->id); ?>">
                                                        <td>#<?php echo e($invoice->id); ?></td>
                                                        <td><?php echo e($invoice->created_at->toFormattedDateString()); ?></td>
                                                        <td class="status<?php echo e($invoice->id); ?>">
                                                            <?php echo e($invoice->is_approved == 1 ? 'Approved' : ($invoice->redo == 1 ? 'Redo' : 'Waiting For Approval')); ?>

                                                        </td>
                                                        <td><?php echo e($invoice->client->name); ?></td>
                                                        <td>
                                                            <?php $__currentLoopData = $invoice->invoice_items->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php echo e($item->name); ?>,

                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($invoice->invoice_items->count() > 3): ?>
                                                                ...
                                                            <?php endif; ?>
                                                        </td>

                                                        <td>৳ <?php echo e(currency_format($invoice->grand_total)); ?></td>

                                                        <td>
                                                            <a href="<?php echo e(route('invoice.pdf', [$invoice->id])); ?>">
                                                                <button type='button' class='btn btn-outline-purple'><i
                                                                        class='fa fa-download'></i></button>
                                                            </a>
                                                            

                                                            <button type='button' class='btn btn-outline-dark'
                                                                onclick='viewinvoice(<?php echo e($invoice->id); ?>)'><i
                                                                    class='fa fa-eye'></i></button>
                                                            <button type='button' class='btn btn-outline-primary '
                                                                onclick='editInvoice(<?php echo e($invoice->id); ?>)'><i
                                                                    class='mdi mdi-pencil'></i></button>
                                                            <button type='button' name='delete'
                                                                class="btn btn-outline-danger"
                                                                onclick="deleteinvoice(<?php echo e($invoice->id); ?>)"><i
                                                                    class="mdi mdi-delete "></i></button>
                                                        </td>

                                                    </tr>
                                                <?php elseif(Auth::user()->is_manager == 1 ): ?>
                                                    <tr class="invoice<?php echo e($invoice->id); ?>">
                                                        <td>#<?php echo e($invoice->id); ?></td>
                                                        <td><?php echo e($invoice->created_at->toFormattedDateString()); ?></td>
                                                        <td class="status<?php echo e($invoice->id); ?>">
                                                            <?php echo e($invoice->is_approved == 1 ? 'Approved' : ($invoice->redo == 1 ? 'Redo' : 'Waiting For Approval')); ?>

                                                        </td>
                                                        <td><?php echo e($invoice->client->name); ?></td>

                                                        <td>
                                                            <?php $__currentLoopData = $invoice->invoice_items->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php echo e($item->name); ?>,
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($invoice->invoice_items->count() > 3): ?>
                                                                ...
                                                            <?php endif; ?>
                                                        </td>

                                                        <td>৳ <?php echo e(currency_format($invoice->grand_total)); ?></td>

                                                        <td>
                                                            <a href="<?php echo e(route('invoice.pdf', [$invoice->id])); ?>">
                                                                <button type='button' class='btn btn-outline-purple'><i
                                                                        class='fa fa-download'></i></button>
                                                            </a>

                                                            <button type='button' class='btn btn-outline-dark'
                                                                onclick='viewinvoice(<?php echo e($invoice->id); ?>)'><i
                                                                    class='fa fa-eye'></i></button>

                                                        </td>

                                                    </tr>
                                                <?php elseif(Auth::user()->id == $invoice->user->id ): ?>
                                                    <tr class="invoice<?php echo e($invoice->id); ?>">
                                                        <td>#<?php echo e($invoice->id); ?></td>
                                                        <td><?php echo e($invoice->created_at->toFormattedDateString()); ?></td>
                                                        <td class="status<?php echo e($invoice->id); ?>">
                                                            <?php echo e($invoice->is_approved == 1 ? 'Approved' : ($invoice->redo == 1 ? 'Redo' : 'Waiting For Approval')); ?>

                                                        </td>
                                                        <td><?php echo e($invoice->client->name); ?></td>
                                                        <td>
                                                            <?php $__currentLoopData = $invoice->invoice_items->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php echo e($item->name); ?>,
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($invoice->invoice_items->count() > 3): ?>
                                                                ...
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>৳ <?php echo e(currency_format($invoice->grand_total)); ?></td>
                                                        <td>
                                                            <a href="<?php echo e(route('invoice.pdf', [$invoice->id])); ?>">
                                                                <button type='button' class='btn btn-outline-purple'><i
                                                                        class='fa fa-download'></i></button>
                                                            </a>
                                                            <button type='button' class='btn btn-outline-dark'
                                                                onclick='viewinvoice(<?php echo e($invoice->id); ?>)'><i
                                                                    class='fa fa-eye'></i></button>
                                                            <?php if($invoice->is_approved == 1): ?>
                                                                <button type='button' class='btn btn-outline-primary '
                                                                    disabled><i class='mdi mdi-pencil'></i></button>
                                                            <?php else: ?>
                                                                <button type='button' class='btn btn-outline-primary '
                                                                    onclick='editInvoice(<?php echo e($invoice->id); ?>)'><i
                                                                        class='mdi mdi-pencil'></i></button>
                                                            <?php endif; ?>

                                                            <?php if($invoice->is_approved == 1 || $invoice->redo == 1): ?>
                                                                <button type='button' name='delete'
                                                                    class="btn btn-outline-danger" disabled><i
                                                                        class="mdi mdi-delete "></i>
                                                                </button>
                                                            <?php else: ?>
                                                                <button type='button' name='delete'
                                                                    class="btn btn-outline-danger"
                                                                    onclick="deleteinvoice(<?php echo e($invoice->id); ?>)"><i
                                                                        class="mdi mdi-delete "></i></button>
                                                            <?php endif; ?>

                                                        </td>

                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->




        </div><!-- container -->

    </div> <!-- Page content Wrapper -->


    <!-- Add  Modal -->
    <div class="modal fade bs-example-modal-center" id="add" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header d-block">
                    <h5 class="modal-title mt-0 text-center">Add New Invoice</h5>
                    <button type="button" class="close modal_close_icon" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body">
                    <form class="invoiceAddForm" method="POST"> <?php echo csrf_field(); ?>
                        <section class="quotation-wrapper">
                            <div>
                                <img src="<?php echo e(asset('images/quotation/header-img.png')); ?>" alt="Company name and header">
                            </div>

                            <div class="row quotation-header align-items-center">
                                <div class="col-5 wreaper-box">
                                    <span class="bill-title">Bill to</span>
                                    <div class="address-box" onclick="openClientSelectModal()">
                                        <p class="client-name"></p>
                                       
                                        <p class="client-info clientPhone"></p>
                                        <p class="client-info clientEmail"></p>
                                        <p class="client-info clientAddress"></p>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <img src="<?php echo e(asset('images/quotation/invoiceimg.png')); ?>" alt="Invoice Image">
                                </div>
                                <div class="col-12">
                                    <div class="row customerInfoDate">
                                        <div class="col-6"></div>
                                        <div class="col-2">
                                            <h4>CUSTOMER NO:</h4>
                                            <h6 class="customerNum"></h6>
                                            <input type="hidden"  name="client" class="client_id">
                                        </div>
                                        <div class="col-2">
                                            <h4>DUE DATE:</h4>
                                            <input type="date" name="due_date">
                                        </div>
                                        <div class="col-2">
                                            <h4>BILLING DATE:</h4>
                                            <input type="date" name="billing_date">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12 pt-2">
                                    
                                    <table class="w-100 invoice-table">
                                        <thead>
                                            <tr>
                                                <!-- <th>NO.</th> -->
                                                <th>ITEM & DESCRIPTION</th>
                                                <th>UNIT PRICE (DEFAULT)</th>
                                                <th>UNIT PRICE</th>
                                                <th>QUANTITY</th>
                                                <th>PRICE</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <!-- <tr>
                                                        <td>1</td>
                                                        <td>
                                                            <select class="form-control" name="selectItem">
                                                                <option value="">Select</option>
                                                                <option value="1">Web Development</option>
                                                                <option value="2">Web Design</option>
                                                                <option value="3">Marketing</option>
                                                                <option value="4">Graphics Design</option>
                                                            </select>
                                                        </td>
                                                        <td> <span class="tk">৳</span> 12885</td>
                                                        <td class="d-flex justify-content-center align-items-center">
                                                            <span class="tk">৳</span><input class="form-control" type="number">
                                                        </td>
                                                        <td>
                                                            <input class="form-control" type="number">
                                                        </td>
                                                        <td>
                                                            <span class="tk">৳</span> 12885
                                                            <button><i class="fas fa-trash"></i></button>
                                                        </td>
                                                    </tr> -->
                                        </tbody>
                                    </table>
                                    

                                    <button onclick="add_row_edit()" type="button" class="addInvBtn">Add New Invoice
                                        Item</button>
                                </div>
                            </div>
                            <div class="row align-items-center">
                                <div class="col-7 payment-box">
                                    <!-- <div class="payment-wraper" data-toggle="modal" data-target="#selectPaymentMethod">
                                                <h3>Payment Method</h3>
                                                <h6>Paypal: companyname@paypal.com</h6>
                                            </div> -->
                                </div>
                                <div class="col-5">
                                    <table class="subtable">
                                        <tr>
                                            <td>SUB TOTAL</td>
                                            <td>
                                                <span class="tk">৳</span>
                                                <span id="subtotal"></span>
                                                <input type="hidden"  name="sub_total" class="subtotal">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Tax: VAT <input class="inline-input" onkeyup="vatAction()" type="number"
                                                    value="15" id="vatInputId">%</td>
                                            <td><span class="tk">৳</span> <span id="taxValueId">0</span><input type="hidden"  name="vat_amount" class="vat_amount"></td>
                                        </tr>
                                        <tr>
                                            <td>DISCOUNT <input class="inline-input" onkeyup="discountAction()"
                                                    type="number" value="7" id="disInputId">%</td>
                                            <td style="color: #EC293B;"><span class="tk">-৳</span> <span
                                                    id="disValueId">0</span>
                                                    <input type="hidden"  name="discount_amount" class="discount_amount"> 
                                                </td>
                                        </tr>
                                        <tr class="grandtotal">
                                            <td>GRAND TOTAL</td>
                                            <td>
                                                <span class="tk">৳</span> <span id="grandTotalValue">0</span>
                                                <input type="hidden"  name="grand_total" class="grand_total">
                                             </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>

                            <div class="row pt-4 pb-2">
                                <div class="col-12 text-right">
                                    <select class="assignSegSelect" name="signatory" id="asignSegnatory">
                                        <option value="">Assign Second Signatory</option>
                                        <option value="manager">Manger</option>
                                    </select>
                                </div>
                            </div>

                            <div>
                                <img src="<?php echo e(asset('images/quotation/footer-img.png')); ?>" alt="Company address footer">
                            </div>
                        </section>

                        <div class="form-group mt-5">
                            <div>
                                <button type="submit" class="btn btn-block btn-success waves-effect waves-light">
                                    Submit
                                </button>

                            </div>
                        </div>
                    </form>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
    <!-- Add  Modal End -->



    <!-- Edit  Modal -->
    <div class="modal fade bs-example-modal-center" id="edit_modal" tabindex="-1" role="dialog"
        aria-labelledby="mySmallModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg  modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header d-block">
                    <h5 class="modal-title mt-0 text-center">Update Invoice</h5>
                    <button type="button" class="close modal_close_icon" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body">

                    <form class="updateinvoiceForm" method="POST"> <?php echo csrf_field(); ?>
                    <section class="quotation-wrapper">
                        <div>
                            <img src="<?php echo e(asset('images/quotation/header-img.png')); ?>" alt="Company name and header">
                        </div>

                        <div class="row quotation-header align-items-center">
                            <div class="col-5 wreaper-box">
                                <span class="bill-title">Bill to</span>
                                <div class="address-box" onclick="openClientSelectModal()">
                                    <p class="client-name"></p>
                                   
                                    <p class="client-info clientPhone"></p>
                                    <p class="client-info clientEmail"></p>
                                    <p class="client-info clientAddress"></p>
                                </div>
                            </div>
                            <div class="col-7">
                                <img src="<?php echo e(asset('images/quotation/invoiceimg.png')); ?>" alt="Invoice Image">
                            </div>
                            <div class="col-12">
                                <div class="row customerInfoDate">
                                    <div class="col-6"></div>
                                    <div class="col-2">
                                        <h4>CUSTOMER NO:</h4>
                                        <h6 class="customerNum"></h6>
                                        <input type="hidden"  name="client" class="client_id">
                                    </div>
                                    <div class="col-2">
                                        <h4>DUE DATE:</h4>
                                        <input class="due_date" type="date" name="due_date">
                                    </div>
                                    <div class="col-2">
                                        <h4>BILLING DATE:</h4>
                                        <input class="billing_date" type="date" name="billing_date">
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 pt-2">
                                
                                <table class="w-100 invoice-table">
                                    <thead>
                                        <tr>
                                            <!-- <th>NO.</th> -->
                                            <th>ITEM & DESCRIPTION</th>
                                            <th>UNIT PRICE (DEFAULT)</th>
                                            <th>UNIT PRICE</th>
                                            <th>QUANTITY</th>
                                            <th>PRICE</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- <tr>
                                                    <td>1</td>
                                                    <td>
                                                        <select class="form-control" name="selectItem">
                                                            <option value="">Select</option>
                                                            <option value="1">Web Development</option>
                                                            <option value="2">Web Design</option>
                                                            <option value="3">Marketing</option>
                                                            <option value="4">Graphics Design</option>
                                                        </select>
                                                    </td>
                                                    <td> <span class="tk">৳</span> 12885</td>
                                                    <td class="d-flex justify-content-center align-items-center">
                                                        <span class="tk">৳</span><input class="form-control" type="number">
                                                    </td>
                                                    <td>
                                                        <input class="form-control" type="number">
                                                    </td>
                                                    <td>
                                                        <span class="tk">৳</span> 12885
                                                        <button><i class="fas fa-trash"></i></button>
                                                    </td>
                                                </tr> -->
                                    </tbody>
                                </table>
                                

                                <button onclick="add_row_edit()" type="button" class="addInvBtn">Add New Invoice
                                    Item</button>
                            </div>
                        </div>
                        <div class="row align-items-center">
                            <div class="col-7 payment-box">
                                <!-- <div class="payment-wraper" data-toggle="modal" data-target="#selectPaymentMethod">
                                            <h3>Payment Method</h3>
                                            <h6>Paypal: companyname@paypal.com</h6>
                                        </div> -->
                            </div>
                            <div class="col-5">
                                <table class="subtable">
                                    <tr>
                                        <td>SUB TOTAL</td>
                                        <td>
                                            <span class="tk">৳</span>
                                            <span id="subtotal" class="sub_total"></span>
                                            <input type="hidden"  name="sub_total" class="subtotal">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Tax: VAT <input class="inline-input" onkeyup="vatAction()" type="number"
                                                value="15" id="vatInputId">%</td>
                                        <td><span class="tk">৳</span> <span id="taxValueId">0</span><input type="hidden"  name="vat_amount" class="vat_amount"></td>
                                    </tr>
                                    <tr>
                                        <td>DISCOUNT <input class="inline-input" onkeyup="discountAction()"
                                                type="number" value="7" id="disInputId">%</td>
                                        <td style="color: #EC293B;"><span class="tk">-৳</span> <span
                                                id="disInputId">0</span>
                                                <input type="hidden"  name="discount_amount" class="discount_amount"> 
                                            </td>
                                    </tr>
                                    <tr class="grandtotal">
                                        <td>GRAND TOTAL</td>
                                        <td>
                                            <span class="tk">৳</span> <span id="grandTotalValue">0</span>
                                            <input type="hidden"  name="grand_total" class="grand_total">
                                         </td>
                                    </tr>
                                </table>
                            </div>
                        </div>

                        <div class="row pt-4 pb-2">
                            <div class="col-12 text-right">
                                <select class="assignSegSelect" name="signatory" id="asignSegnatory">
                                    <option value="">Assign Second Signatory</option>
                                    <option value="manager">Manger</option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <img src="<?php echo e(asset('images/quotation/footer-img.png')); ?>" alt="Company address footer">
                        </div>
                    </section>
                </form>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
    <!-- Edit  Modal End -->
    <!-- client set  Modal start -->
    <div class="modal fade" id="getClientModal" data-toggle="modal" tabindex="-1" aria-labelledby="staticBackdropLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title invModal-title">Set the client for this invoice</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <select class="form-control" name="client" id="client">
                </select>
                <!-- data-dismiss="modal" aria-label="Close" -->
                <div class="text-right pt-3">
                    <button class="btn btn-dark" onclick="clientSetAction()" id="clientSetId">SET</button>
                </div>
            </div>
        </div>
    </div>
</div>
    <!-- client set Modal End -->

    <!-- view  Modal -->
    <div class="modal fade bs-example-modal-center" id="viewModal" tabindex="-1" role="dialog"
        aria-labelledby="mySmallModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg invoice_modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header d-block">
                    <h5 class="modal-title mt-0 text-center">Invoice Details</h5>
                    <p class="text-center prepare_by mt-3"></p>
                    <button type="button" class="close modal_close_icon view_modal_close_icon" data-dismiss="modal"
                        aria-hidden="true">×</button>
                </div>
                <div class="modal-body">
                    <table border="0" cellpadding='0' cellspacing="0"
                        style="max-width:595px; width: 100%; height: 200px; min-width:595px;" align="center">


                        <tr>
                            <td colspan="5" style="vertical-align: top; height: 132px;"><img
                                    style="width: 100%; height: 100%;"
                                    src="<?php echo e(asset('images/quotation/header-img.png')); ?>" alt="Heade Image"></td>

                        </tr>

                        <tr>
                            <td colspan="2" style="padding-left: 42px; text-align:initial;">
                                <span
                                    style="height: 13px; width: 41px; font-size: 10px; line-height: 12px; padding: 3px 14px; background-color: #242424; color: #FFFFFF; font-family: 'Roboto', sans-serif;">Bill
                                    to</span>

                                <h3 class="client_name"
                                    style="font-family: 'Roboto' sans-serif; margin-top: 6px; margin-bottom: 5px; font-style: normal; font-weight: normal; font-size: 12px; line-height: 12px; color: #37454E;">
                                </h3>

                                <h4 class="client_phone"
                                    style="margin-bottom: 2px;margin-top: 0px;font-family: 'Roboto', sans-serif; font-style: normal; font-weight: 400; font-size: 10px; line-height: 10px; color: #44515a; ">
                                    <span style="font-weight: 700;color: #37454E;">P:</span>
                                </h4>
                                <h4 class="client_email"
                                    style="margin-bottom: 2px;margin-top: 0px;font-family: 'Roboto', sans-serif; font-style: normal; font-weight: 400; font-size: 10px; line-height: 10px; color: #44515a; ">
                                    <span style="font-weight: 700;color: #37454E;">E:</span>
                                </h4>
                                <h4 class="client_address"
                                    style="margin-bottom: 2px;margin-top: 0px;font-family: 'Roboto', sans-serif; font-style: normal; font-weight: 400; font-size: 10px; line-height: 10px; color: #44515a; max-width: 140px; ">

                                </h4>
                            </td>

                            <td colspan="3" style="text-align: left;">
                                <img style="width: 140px;" src="<?php echo e(asset('images/quotation/invoiceimg.png')); ?>"
                                    alt="Invoice Image">
                            </td>
                        </tr>

                        <tr>
                            <td colspan="5">
                                <table style="width: 100%;">
                                    <tr>
                                        <td style="width: 42%;"></td>
                                        <td>
                                            <h3
                                                style="margin: 0;font-family: 'Roboto', sans-serif; font-weight: 700; font-style: normal; font-size: 8px; line-height: 10px; color: #37454E;">
                                                INVOICE NO:</h3>
                                            <h4 class="invoice_id"
                                                style="margin: 0;font-family: 'Roboto', sans-serif;;color: #37454E;font-weight: 400; font-style: normal; font-size: 8px; line-height: 10px;">
                                                #</h4>
                                        </td>
                                        <td>
                                            <h3
                                                style="margin: 0;font-family: 'Roboto', sans-serif; font-weight: 700; font-style: normal; font-size: 8px; line-height: 10px; color: #37454E;">
                                                CUSTOMER NO :</h3>
                                            <h4 class="customer_id"
                                                style="margin: 0;color: #37454E;font-family: 'Roboto', sans-serif;font-weight: 400; font-style: normal; font-size: 8px; line-height: 10px;">
                                                #</h4>
                                        </td>
                                        <td>
                                            <h3
                                                style="margin: 0;font-family: 'Roboto', sans-serif; font-weight: 700; font-style: normal; font-size: 8px; line-height: 10px; color: #37454E;">
                                                Due DATE:</h3>
                                            <h4 class="due_date"
                                                style="margin: 0;color: #37454E;font-family: 'Roboto', sans-serif;font-weight: 400; font-style: normal; font-size: 8px; line-height: 10px;">
                                            </h4>
                                            
                                        </td>
                                        <td>
                                            <h3
                                                style="margin: 0;font-family: 'Roboto', sans-serif; font-weight: 700; font-style: normal; font-size: 8px; line-height: 10px; color: #37454E;">
                                                Billing DATE:</h3>
                                            <h4 class="billing_date"
                                                style="margin: 0;color: #37454E;font-family: 'Roboto', sans-serif;font-weight: 400; font-style: normal; font-size: 8px; line-height: 10px;">
                                            </h4>
                                        </td>

                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="5" style="padding-top: 9px;">
                                <table style="width: 100%;">

                                    <tr>
                                        <td
                                            style="padding: 7px 6px; background: #3B3B3B; color: #FFFFFF; font-family: 'Roboto', sans-serif; font-size: 14px; line-height: 17px; text-align: center; font-weight: 700; width: 1%">
                                            NO.</td>

                                        <td
                                            style="background: #F5BC49; padding: 7px 6px;font-family: 'Roboto', sans-serif; font-style: normal; font-weight: 700; font-size: 14px; line-height: 17px; text-align: center; width: 17%; ">
                                            ITEM & DESCRIPTION
                                        </td>
                                        <td
                                            style="padding: 7px 6px; background: #3B3B3B; color: #FFFFFF; font-family: 'Roboto', sans-serif; font-size: 14px; line-height: 17px; text-align: center; font-weight: 700; width: 7%">
                                            UNIT PRICE</td>
                                        <td
                                            style="padding: 7px 6px; background: #3B3B3B; color: #FFFFFF; font-family: 'Roboto', sans-serif; font-size: 14px; line-height: 17px; text-align: center; font-weight: 700; width: 2%">
                                            QUANTITY</td>
                                        <td
                                            style="padding: 7px 6px; background: #3B3B3B; color: #FFFFFF; font-family: 'Roboto', sans-serif; font-size: 14px; line-height: 17px; text-align: center; font-weight: 700; width: 7%">
                                            PRICE</td>
                                    </tr>
                                    <tbody class="table-body table_items">
                                        




                                    </tbody>
                                </table>
                            </td>

                        </tr>
                        <tr>
                            <td colspan="5">
                                <table style="width: 100%; border-spacing: 0; margin-top: 5px;">
                                    <tr>
                                        <td colspan="3" style="width: 62%; text-align:initial;">

                                            <span
                                                style="font-family: 'Roboto', sans-serif; font-weight: 700; font-size: 14px; font-style: normal; line-height: 17px;color: #000000; padding-top: 18px; padding-left: 42px; display: inline-block; padding-bottom: 6px;">Payment
                                                Method</span>


                                            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <h4
                                                    style="margin-bottom: 2px;margin-top: 0px;font-family: 'Roboto', sans-serif; font-style: normal; font-weight: 400; font-size: 8px; line-height: 10px; color: #44515a; width: 75%;">
                                                    
                                                    <?php echo e($payment->description); ?>

                                                </h4>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>

                                        <td colspan="2" style="vertical-align: top;">
                                            <table style="width: 100%;">
                                                <tr>
                                                    <td
                                                        style="font-family: 'Roboto', sans-serif;font-weight: 700; font-style: normal; font-size: 10px; line-height: 12px;color: #525453; background-color: #ECEAEB; padding: 5px 0 5px 10px;">
                                                        SUB TOTAL</td>
                                                    <td class="sub_total"
                                                        style="font-family: 'Roboto', sans-serif;font-weight: 700; font-style: normal; font-size: 10px; line-height: 12px;color: #313131; background-color: #ECEAEB; text-align: center;">
                                                        ৳ </td>
                                                </tr>
                                                <tr class="vat_row">
                                                    <td class="vat"
                                                        style="font-family: 'Roboto', sans-serif;font-weight: 700; font-style: normal; font-size: 10px; line-height: 12px;color: #525453; background-color:  #F8F8F8; padding: 5px 0 5px 10px;">
                                                    </td>
                                                    <td class="vat_amount"
                                                        style="font-family: 'Roboto', sans-serif;font-weight: 700; font-style: normal; font-size: 10px; line-height: 12px;color: #313131; background-color:  #F8F8F8; text-align: center;">
                                                        ৳ </td>
                                                </tr>
                                                

                                                <tr>
                                                    <td
                                                        style="font-family: 'Roboto', sans-serif;font-weight: 700; font-style: normal; font-size: 14px; line-height: 17px;color: #FFFFFF; background-color: #3B3B3B; padding: 5px 0; text-align: center;">
                                                        GRAND TOTAL</td>
                                                    <td class="grand_total"
                                                        style="font-family: 'Roboto', sans-serif;font-weight: 700; font-style: normal; font-size: 14px; line-height: 17px;color: #080807; background-color: #F5BC49; text-align: center;">
                                                        ৳ </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </td>

                        </tr>

                        <tr>
                            <td colspan="2" style="padding-top: 16px; text-align:initial;">
                                <h3
                                    style="font-family: 'Roboto', sans-serif;font-style: italic; font-weight: 700; font-size: 10px; line-height: 12px; color: #37454E; padding-left: 42px;margin-bottom: 5px;">
                                    Terms & Notes</h3>
                                <ul style="margin:0">
                                    <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li
                                            style="list-style-type: none; color: #000000;font-family: 'Roboto', sans-serif; font-style: normal;font-weight: normal; font-size: 9px; line-height: 11px; padding-left: 20px;">
                                            # <?php echo e($term->description); ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </ul>
                            </td>


                            <td colspan="2" style="text-align: center; vertical-align: middle;" class="ceo_signature">
                                <span style="padding-top: 40px; display: inline-block;">...........................</span>
                                <br>
                                <span class="employee_name"
                                    style="font-family: 'Roboto', sans-serif; font-style: normal; font-weight: 400; font-size: 14px; line-height: 17px; text-align: center; color: #000000;">
                                    
                                </span> <br>
                                <span class="designation"
                                    style="font-family: 'Roboto', sans-serif; font-style: italic; font-weight: 700; font-size: 14px; line-height: 17px; text-align: center; color: #000000;">Designation
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="5">
                                <img style="width: 100%;" src="<?php echo e(asset('images/quotation/footer-img.png')); ?>" alt="">
                            </td>
                        </tr>

                        <tr>
                            <td colspan="5" style="text-align: right; padding-top: 10px; padding-bottom: 20px;">

                                <button class="print_button" onclick="printInvoice()"
                                    style="background-color: #3B3B3B;font-family: 'Roboto', sans-serif; color: white; border: none; cursor: pointer;font-weight: 700; padding:3px 10px;">Print</button>






                            </td>
                        </tr>

                    </table>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
    <!-- view  Modal End -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageScripts'); ?>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>

    <script src="<?php echo e(asset('backend/assets/js/calulation.js')); ?>"></script>
    <script type='text/javascript'>
        var toastMixin = Swal.mixin({
            toast: true,
            title: 'General Title',
            animation: false,
            position: 'top-right',
            showConfirmButton: false,
            timer: 5000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        });
        var config = {
            routes: {
                add: "<?php echo route('invoice.store'); ?>",
                edit: "<?php echo route('invoice.edit'); ?>",
                view: "<?php echo route('invoice.show'); ?>",
                update: "<?php echo route('invoice.update'); ?>",
                delete: "<?php echo route('invoice.delete'); ?>",
                getItemPrice: "<?php echo route('item.price'); ?>",
                update_approve_status: "<?php echo route('invoice.approve.status.update'); ?>",
            }
        };
        $('#addButton').on('click', function() {
            $('.invoiceAddForm').trigger('reset');
            // $('.select2-selection__rendered').empty();
        });
        // data table
        $(document).ready(function() {
            $('#invoiceTable').DataTable({
                "ordering": false,
                // "orderSequence": [ "desc" ]
            });

            $(".close_btn").hide();
            $(".manager_selcet_box").hide();
            $('.select_manager').prop('disabled', true);
            // $('.amount').autoNumeric('init', {aSign: '৳ ', mDec:2});
        });

        // add form validation
        $(document).ready(function() {
            $(".invoiceAddForm").validate({
                rules: {
                    client: {
                        required: true,
                    },
                    signatory_id: {
                        required: true,
                    },
                    'item[]': {
                        required: true,
                    },

                    quantity: {
                        required: true,
                        digits: true,
                        maxlength: 20,
                    },
                    grand_total: {
                        required: true,
                        // digits: true,
                        maxlength: 20,
                    },
                    due_date: {
                        required: true,
                    },
                    billing_date: {
                        required: true,
                    },
                    precedence: {
                        required: true,
                        maxlength: 1000,
                    },
                },
                messages: {
                    client: {
                        required: 'Please select a client',
                    },
                    employee: {
                        required: 'Please select an employee',
                    },
                    ' item[]': {
                        required: 'Please select an item',
                    },
                    quantity: {
                        required: 'Please insert quantity',
                    },
                    grand_total: {
                        required: 'Please insert grand total',
                    },
                    due_date: {
                        required: 'Please insert due date',
                    },
                    billing_date: {
                        required: 'Please insert billing date',
                    },
                    precedence: {
                        required: 'Please insert precedence',
                    },
                },
                errorPlacement: function(label, element) {
                    label.addClass('mt-2 text-danger');
                    label.insertAfter(element);
                },
            });
        });
        //end

        // add  request
        $(document).on('submit', '.invoiceAddForm', function(event) {
            event.preventDefault();
            // alert('submit')
            var data = new FormData(this);
            console.log(data);
            var token = $('input[name=_token]');
            $.ajax({
                url: config.routes.add,
                method: "POST",
                // data: {
                //     new_data: data,
                //     val : 'val',
                // },
                data:data,
                contentType: false,
                cache: false,
                processData: false,
                dataType: "json",

                success: function(response) {

                    if (response.success == true) {
                        var pdf_url = '<?php echo e(route('invoice.pdf', ':id')); ?>';
                        pdf_url = pdf_url.replace(':id', response.data.id);
                        var invoice_details_url = '<?php echo e(route('invoice.details', ':id')); ?>';
                        invoice_details_url = invoice_details_url.replace(':id', response.data.id);
                        var invoiceTable = $('#invoiceTable').DataTable();
                        var trDOM = invoiceTable.row.add([
                            "#" + response.data.id + "",
                            "" + response.data.date + "",
                            "" + response.data.status + "",
                            "" + response.data.client + "",
                            // "" + response.data.item + "",
                            `${response.data.total_items > 3 ?  `${response.data.item } ...` : response.data.item }`,
                            // "" + response.data.quantity + "",
                            "৳ " + bdCurrencyFormat(response.data.grand_total) + "",

                            `
                            <a href="${pdf_url}">
                                <button type='button' class='btn btn-outline-purple'>
                                    <i class='fa fa-download'></i>
                                </button>
                            </a>

                            <button type='button' class='btn btn-outline-dark' onclick='viewinvoice(${ response.data.id})'>
                                <i class='fa fa-eye'></i>
                            </button>
                            <button type='button' class='btn btn-outline-primary' onclick='editInvoice(${response.data.id})'>
                                <i class='mdi mdi-pencil'></i>
                            </button>
                            <button type='button' name='delete' class="btn btn-outline-danger"onclick="deleteinvoice(${response.data.id})">
                                <i class="mdi mdi-delete "></i>
                            </button>
                            `
                        ]).draw().node();
                        $(trDOM).addClass('invoice' + response.data.id + '');
                        $('.invoiceAddForm').trigger('reset');
                        if (response.data.message) {
                            toastMixin.fire({
                                icon: 'success',
                                animation: true,
                                title: "" + response.data.message + ""
                            });

                        }


                    } else {
                        html = `<div class="alert alert-danger text-center" role="alert">
                                    <strong>${response.data.error}</strong>.
                                </div>
                            `;
                        $('.showError').fadeIn(100).html(html);
                        $('.showError').fadeOut(5000);
                    }
                }, //success end

                beforeSend: function() {
                    $('#add').modal('hide');
                    $('.preloader').empty();
                    $('.preloader').addClass('ajax_loader').append(
                        `<div class='preloader'>
                            <div id="status">
                                <div class="spinner"></div>
                            </div>
                        </div>`
                    );
                },
                complete: function() {
                    $('.preloader').removeClass('ajax_loader').empty();
                }
            });
        });

        //request end


        // view single 
        function viewinvoice(id) {
            $.ajax({
                url: config.routes.view,
                method: "POST",
                data: {
                    id: id,
                    _token: "<?php echo e(csrf_token()); ?>"
                },
                dataType: "json",
                success: function(response) {
                    if (response.success == true) {
                        $('.client_name').text(response.data.client_name);
                        $('.employee_name').text(response.data.super_admin.name);
                        $('.designation').text(response.data.super_admin.designation);

                        $('.client_phone').text(response.data.client_phone);
                        $('.prepare_by').html(`<strong>Prepared By:</strong> ${response.data.prepare_by}`);
                        $('.client_email').text(response.data.client_email);
                        $('.client_address').text(response.data.client_address);
                        $('.invoice_id').text('#'+response.data.id);
                        $('.customer_id').text('#'+response.data.client_id);
                        $('.due_date').text(response.data.formated_due_date);
                        $('.billing_date').text(response.data.formated_billing_date);
                        $('.sub_total').text('৳ ' + response.data.sub_total);
                        $('.grand_total').text('৳ ' + response.data.grand_total);
                        $('.vat').text('Tax: VAT ' + response.data.vat + ' %');
                        $('.vat_amount').text('৳ ' + response.data.vat_amount);
                        $('.signatory_row').remove();
                        if (response.data.signatory_id != null) {
                            $('.ceo_signature').before(
                                ` <td style="text-align: center; vertical-align: middle;" class="signatory_row">
                                <span style="padding-top: 40px; display: inline-block;">...........................</span>
                                <br>
                                <span class="manager"
                                    style="font-family: 'Roboto', sans-serif; font-style: normal; font-weight: 400; font-size: 14px; line-height: 17px; text-align: center; color: #000000;">${response.data.sigator_name}
                                </span> <br>
                                <span
                                    style="font-family: 'Roboto', sans-serif; font-style: italic; font-weight: 700; font-size: 14px; line-height: 17px; text-align: center; color: #000000;">${response.data.sigator_designation}</span>
                            </td>`
                            );
                        }
                        var pdf_url = '<?php echo e(route('invoice.pdf', ':id')); ?>';
                        pdf_url = pdf_url.replace(':id', response.data.id);

                        $('.download_button').empty();
                        $('.print_button').after(
                            `<a href="${pdf_url}" class="download_button">
                                <button  style="background-color: #F5BC49;font-family: 'Roboto', sans-serif; color: #080807; border: none; cursor: pointer;font-weight: 700; padding:3px 10px;">Download</button>
                            </a>`
                        );
                        $('.approve_button').remove();
                        if (response.data.is_approved == 0) {
                            if (response.data.user_id == 1) {
                                $('.print_button').before(
                                    ` <button class="approve_button" onclick="approveQuotation(${response.data.id})"
                                    style="background-color: #3B3B3B; margit-right:5px; font-family: 'Roboto', sans-serif; color: white; border: none; cursor: pointer;font-weight: 700; padding:3px 10px;">Approve </button>
                            `
                                );
                            } else {
                                $('.print_button').before(
                                    ` <button class="approve_button disabled" 
                                    style="background-color: #3B3B3B; margit-right:5px; font-family: 'Roboto', sans-serif; color: white; border: none; cursor: pointer;font-weight: 700; padding:3px 10px;">Waiting for approval</button>
                            `
                                );
                            }

                        } else if (response.data.is_approved == null) {
                            $('.print_button').before(
                                ` <button class="approve_button disabled" onclick="approveQuotation(${response.data.id})"
                                    style="background-color: #3B3B3B; margit-right:5px; font-family: 'Roboto', sans-serif; color: white; border: none; cursor: pointer;font-weight: 700; padding:3px 10px;">Requested To Redo </button>
                            `
                            );
                        } else {
                            $('.print_button').before(
                                ` <button class="approve_button disabled" onclick="approveQuotation(${response.data.id})"
                                    style="background-color: #3B3B3B; margit-right:5px; font-family: 'Roboto', sans-serif; color: white; border: none; cursor: pointer;font-weight: 700; padding:3px 10px;">Approved  <span class="approve_icon"><i class="fa fa-check"></i></span></button>
                            `
                            );
                        }


                        $('.discount_row').empty();
                        if (response.data.discount != 0) {
                            $('.vat_row').after(
                                ` <tr class = "discount_row">
                                    <td style="font-family: 'Roboto', sans-serif;font-weight: 700; font-style: normal; font-size: 10px; line-height: 12px;color: #525453; background-color: #ECEAEB; padding: 5px 0 5px 10px;">
                                        DISCOUNT ${ response.data.discount }%</td>
                                     <td style="font-family: 'Roboto', sans-serif;font-weight: 700; font-style: normal; font-size: 10px; line-height: 12px;color: #EC293B; background-color: #ECEAEB; text-align: center;">
                                        - ৳ ${ bdCurrencyFormat(response.data.discount_amount) }</td>
                                </tr>`
                            );
                        }
                        $('.table_items').empty();
                        $.each(response.data.invoice_items, function(key, item) {
                            if (key % 2 == 0) {
                                $('.table_items').append(
                                    ` <tr>
                                                <td
                                                    style="font-family: 'Roboto', sans-serif; text-align:initial; font-size: 12px; line-height: 15px; text-align: center; color: #000000;font-style: normal; font-weight: 400; padding: 21px 0;background-color:  #F8F8F8;">
                                                    ${ ++key }</td>
                                                <td
                                                    style="padding-top: 5px; text-align:initial; padding-bottom:  5px;font-family: 'Roboto', sans-serif; font-size: 12px; line-height: 15px; color: #000000;font-style: normal; font-weight: 400; background-color:  #F8F8F8;">
                                                    <span
                                                        style="padding-left: 20px;font-weight: 700; display: inline-block; padding-right: 10px;">
                                                        ${ item.name }
                                                    </span>
                                                    <br>
                                                    <span
                                                        style="padding-left: 20px; display: inline-block; font-size: 9px; padding-right: 10px;">
                                                        ${ item.description }</span>
            
            
                                                </td>
                                                <td
                                                    style="padding-top: 5px; padding-bottom: 5px;font-family: 'Roboto', sans-serif; font-size: 12px; line-height: 15px; color: #000000;font-style: normal; font-weight: 400; text-align: center; background-color:  #F8F8F8;">
                                                    ৳ ${bdCurrencyFormat(item.pivot.unit_price) }
                                                </td>
                                                <td
                                                    style="padding-top: 5px; padding-bottom: 5px;font-family: 'Roboto', sans-serif; font-size: 12px; line-height: 15px; color: #000000;font-style: normal; font-weight: 400; text-align: center; background-color:  #F8F8F8;">
                                                    ${ item.pivot.quantity }
                                                </td>
                                                <td
                                                    style="padding-top: 5px; padding-bottom: 5px;font-family: 'Roboto', sans-serif; font-size: 12px; line-height: 15px; color: #000000;font-style: normal; font-weight: 400; text-align: center; background-color:  #F8F8F8;">
                                                    ৳ ${ bdCurrencyFormat(item.pivot.unit_price * item.pivot.quantity) }
                                                </td>
                                            </tr>          
                               `
                                );
                            } else {
                                $('.table_items').append(
                                    ` <tr>
                                                <td
                                                    style="font-family: 'Roboto', sans-serif; font-size: 12px; line-height: 15px; text-align: center; color: #000000;font-style: normal; font-weight: 400; padding: 21px 0;background-color:  #ECEAEB; ">
                                                    ${++key}</td>
                                                <td
                                                    style="padding-top: 5px; text-align: initial; padding-bottom: 5px;font-family: 'Roboto', sans-serif; font-size: 12px; line-height: 15px; color: #000000;font-style: normal; font-weight: 400; background-color:  #ECEAEB;">
                                                    <span
                                                        style="padding-left: 20px;font-weight: 700; display: inline-block; padding-right: 10px;">
                                                        ${item.name }</span>
                                                    <br>
                                                    <span
                                                        style="padding-left: 20px; display: inline-block; font-size: 9px; padding-right: 10px;">
                                                        ${item.description }</span>
            
            
                                                </td>
                                                <td
                                                    style="padding-top: 5px; padding-bottom: 5px;font-family: 'Roboto', sans-serif; font-size: 12px; line-height: 15px; color: #000000;font-style: normal; font-weight: 400; text-align: center; background-color:  #ECEAEB;">
                                                    ৳ ${bdCurrencyFormat(item.pivot.unit_price) }
                                                </td>
                                                <td
                                                    style="padding-top: 5px; padding-bottom: 5px;font-family: 'Roboto', sans-serif; font-size: 12px; line-height: 15px; color: #000000;font-style: normal; font-weight: 400; text-align: center; background-color:  #ECEAEB;">
                                                    ${item.pivot.quantity}
                                                </td>
                                                <td
                                                    style="padding-top: 5px; padding-bottom: 5px;font-family: 'Roboto', sans-serif; font-size: 12px; line-height: 15px; color: #000000;font-style: normal; font-weight: 400; text-align: center; background-color:  #ECEAEB;">
                                                    ৳${ bdCurrencyFormat(item.pivot.unit_price * item.pivot.quantity) }
                                                </td>
                                            </tr>`
                                );

                            }
                        });

                        $('#viewModal').modal('show');

                    } //success end

                }
            }); //ajax end
        }




        // Update product
        //validation
        $(document).ready(function() {
            $(".updateinvoiceForm").validate({
                rules: {
                    client: {
                        required: true,
                    },
                    signatory_id: {
                        required: true,
                    },
                    'item[]': {
                        required: true,
                    },

                    quantity: {
                        required: true,
                        digits: true,
                        maxlength: 20,
                    },
                    grand_total: {
                        required: true,
                        // digits: true,
                        maxlength: 20,
                    },
                    due_date: {
                        required: true,
                    },
                    billing_date: {
                        required: true,
                    },
                    precedence: {
                        required: true,
                        maxlength: 1000,
                    },
                },
                messages: {
                    client: {
                        required: 'Please select a client',
                    },
                    employee: {
                        required: 'Please select an employee',
                    },
                    ' item[]': {
                        required: 'Please select an item',
                    },
                    quantity: {
                        required: 'Please insert quantity',
                    },
                    grand_total: {
                        required: 'Please insert grand total',
                    },
                    due_date: {
                        required: 'Please insert due date',
                    },
                    billing_date: {
                        required: 'Please insert billing date',
                    },
                    precedence: {
                        required: 'Please insert precedence',
                    },
                },
                errorPlacement: function(label, element) {
                    label.addClass('mt-2 text-danger');
                    label.insertAfter(element);
                },
            });
        });


        var edit_item_row_length;

        function editInvoice(id) {
            $.ajax({
                url: config.routes.edit,
                method: "POST",
                data: {
                    id: id,
                    _token: "<?php echo e(csrf_token()); ?>"
                },
                dataType: "json",
                success: function(response) {
                    if (response.success == true) {
                        edit_item_row_length = response.data.invoice_items.length;
                        $('.client_id').val(response.data.client_id)
                        $('.customerNum').html('#'+response.data.client_id)
                        $('.client-name').html(response.data.client.name);
                        $('.clientPhone').html(response.data.client.phone);
                        $('.clientEmail').html(response.data.client.email);
                        $('.clientAddress').html(response.data.client.address);
                        $('.due_date').val(response.data.edit_due_date)
                        $('.billing_date').val(response.data.edit_billing_date)

                        $('.grand_total').val( bdCurrencyFormat(response.data.grand_total))
                        $('#grandTotalValue').html( bdCurrencyFormat(response.data.grand_total))
                        $('.sub_total').html(bdCurrencyFormat(response.data.sub_total))
                        $('.subtotal').val(bdCurrencyFormat(response.data.sub_total))

                        $('#edit_vat').val(two_decimal(response.data.vat))
                        $('#edit_vat_amount').val('৳ ' + bdCurrencyFormat(response.data.vat_amount))
                        $('#edit_discount').val(two_decimal(response.data.discount))
                        $('#edit_discount_amount').val('৳ ' + bdCurrencyFormat(response.data.discount_amount))
                       

                        $('#edit_employee').val('');
                        $('.assign_manager_checkbox').prop('checked', false);
                        $('.select_manager').prop('disabled', true);
                        $('.manager_selcet_box').hide();
                        if (response.data.signatory_id != null) {
                            $('#edit_employee').val(response.data.signatory_id);
                            $('.assign_manager_checkbox').prop('checked', true);
                            $('.manager_selcet_box').show();
                            $('.select_manager').prop('disabled', false);
                        }


                        $('#edit_grand_total').val('৳ ' + bdCurrencyFormat(response.data.grand_total))
                        $('#edit_sub_total').val('৳ ' + bdCurrencyFormat(response.data.sub_total))
                        $('#edit_vat').val(two_decimal(response.data.vat))
                        $('#edit_vat_amount').val('৳ ' + bdCurrencyFormat(response.data.vat_amount))
                        $('#edit_discount').val(two_decimal(response.data.discount))
                        $('#edit_discount_amount').val('৳ ' + bdCurrencyFormat(response.data.discount_amount))
                       
                        $('#hidden_id').val(response.data.id)
                        $('.edit_item_row').empty();
                        $.each(response.data.invoice_items, function(key, value) {
                            console.log();
                            $('.edit_item_row').append(
                                ` <div class="form-row item_row_edit data${key}" style="padding-bottom:20px">

                            <div class="col-xl-3 col-md-12 mb-3">

                                <div class="ms-form-group">
                                    <label for="validationCustom10">Select Item</label>
                                    <select class="form-control" name="item[${key}][item_id]" 
                                        class="form-control item_id item${key}" id="item" data-id="${key}">
                                        <option value="">Select Item</option>
                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" ${value.id==<?php echo e($item->id); ?> ? 'selected' : '' }>
                                                <?php echo e($item->name ?? 'not found'); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                    <p class="text-danger error_msg${key} "></p>
                                   
                                </div>

                            </div>
                            <div class="col-xl-2 col-md-12 mb-3">
                                <div class="ms-form-group">
                                    <label for="validationCustom10">Quantity</label>
                                    <input type="number" name="item[${key}][quantity]"
                                        class="form-control edit_quantity edit_item_quantity${key}" placeholder="Quantity"
                                        data-id="${key}" value="${value.pivot.quantity}">
                                    <p class="text-danger error_msg0 qty_error_msg${key}"></p>
                                   
                                </div>
                            </div>
                            <div class="col-xl-2 col-md-12 mb-3">
                                <div class="ms-form-group" id="unit_price_div">
                                    <label for="validationCustom10">Unit Price (Default)</label>
                                    <input type="text" name="unit_price" class="form-control edit_default_price${key}"
                                        placeholder="Unit Price" data-id="${key}" readonly value="${'৳ ' + bdCurrencyFormat(value.unit_price)}">
                                    <p class="text-danger error_msg${key}"></p>
                                   
                                </div>
                            </div>
                            <div class="col-xl-2 col-md-12 mb-3">
                                <div class="ms-form-group">
                                    <label for="validationCustom10">Unit Price</label>
                                    <input type="text" name="item[${key}][unit_price]" class="form-control edit_unit_price edit_unit_price${key}" id="edit_unit_price${key}"
                                        placeholder="Unit Price" data-id="${key}" value="${'৳ ' + bdCurrencyFormat(value.pivot.unit_price)}">
                                    <p class="text-danger error_msg${key}"></p>
                                   
                                </div>
                            </div>
                            <div class="col-xl-2 col-md-12 mb-3">
                                <div class="ms-form-group">
                                    <label for="validationCustom10"> Price</label>
                                    <input type="text" name="item[${key}][price]" class="form-control price edit_item_price${key}"
                                        placeholder="Price" data-id="${key}" readonly value="${'৳ ' + bdCurrencyFormat(value.pivot.quantity * value.pivot.unit_price)}">
                                    <p class="text-danger error_msg${key} "></p>


                                </div>
                            </div>
                            <div class="col-xl-1 col-md-12 mb-3">
                                ${response.data.invoice_items.length > 1 ? 
                                    `<span class="float-right close_btn remove_row${key}" onclick="removeRow(${key})">
                                                                                <i class="fa fa-window-close"></i>
                                                                            </span>` : ''}
                               
                            </div>

                        </div>`);
                        });


                        $('#edit_modal').modal('show');

                    } //success end

                }
            });
            $(document).off('submit', '.updateinvoiceForm');
            $(document).on('submit', '.updateinvoiceForm', function(event) {
                event.preventDefault();
                $.ajax({
                    url: config.routes.update,
                    method: "POST",
                    data: new FormData(this),
                    contentType: false,
                    cache: false,
                    processData: false,
                    dataType: "json",
                    success: function(response) {

                        if (response.success == true) {
                            var pdf_url = '<?php echo e(route('invoice.pdf', ':id')); ?>';
                            pdf_url = pdf_url.replace(':id', response.data.id);
                            var invoice_details_url = '<?php echo e(route('invoice.details', ':id')); ?>';
                            invoice_details_url = invoice_details_url.replace(':id', response.data.id);
                            $('.invoice' + response.data.id).html(
                                `
                                <td>#${response.data.id}</td>
                                <td>${response.data.date}</td>
                                <td class="status${response.data.id}">${response.data.status}</td>
                                <td>${response.data.client}</td>
                                <td>${response.data.total_items > 3 ?  `${response.data.item } ...` : response.data.item }</td>
                                <td>৳ ${bdCurrencyFormat(response.data.grand_total)}</td>
           
                                <td>
                                    <a href="${pdf_url}">
                                <button type='button' class='btn btn-outline-purple'>
                                    <i class='fa fa-download'></i>
                                </button>
                            </a>
                            <button type='button' class='btn btn-outline-dark' onclick='viewinvoice(${ response.data.id})'>
                                <i class='fa fa-eye'></i>
                            </button>
                            ${response.data.approved == 1 ? 
                                `<button type='button' class='btn btn-outline-primary' disabled onclick='editInvoice(${response.data.id})'>
                                                        <i class='mdi mdi-pencil'></i>
                                                    </button>` : 
                                ` <button type='button' class='btn btn-outline-primary' onclick='editInvoice(${response.data.id})'>
                                                        <i class='mdi mdi-pencil'></i>
                                                    </button>`
                            
                            }
                            ${(response.data.approved == 1 || response.data.redo == 1) ? 
                                ` <button type='button' name='delete' disabled class="btn btn-outline-danger"onclick="deleteinvoice(${response.data.id})">
                                                        <i class="mdi mdi-delete "></i>
                                                    </button>` :
                                ` <button type='button' name='delete' class="btn btn-outline-danger"onclick="deleteinvoice(${response.data.id})">
                                                        <i class="mdi mdi-delete "></i>
                                                    </button>`
                            }
                             </td>
                                `
                            );

                            if (response.data.message) {
                                toastMixin.fire({
                                    icon: 'success',
                                    animation: true,
                                    title: "" + response.data.message + ""
                                });
                                $('.updateinvoiceForm')[0].reset();
                            }


                        } else {
                            html = `<div class="alert alert-danger text-center" role="alert">
                                    <strong>${response.data.error}</strong>.
                                </div>
                            `;
                            $('.showError').fadeIn(100).html(html);
                            $('.showError').fadeOut(3000);

                        }

                    }, //success end

                    beforeSend: function() {
                        $('#edit_modal').modal('hide');
                        $('.preloader').empty();
                        $('.preloader').addClass('ajax_loader').append(
                            `<div class='preloader'>
                            <div id="status">
                                <div class="spinner"></div>
                            </div>
                        </div>`
                        );
                    },
                    complete: function() {
                        $('.preloader').removeClass('ajax_loader').empty();
                    }
                });
            });

        }



        // delete slider
        function deleteinvoice(id) {
            // alert(id)
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        type: "POST",
                        url: config.routes.delete,
                        data: {
                            id: id,
                            _token: "<?php echo e(csrf_token()); ?>"
                        },
                        dataType: 'JSON',
                        success: function(response) {
                            if (response.success === true) {
                                Swal.fire(
                                    'Deleted!',
                                    "" + response.data.message + "",
                                    'success'
                                )
                                // swal("Done!", response.data.message, "success");
                                $('#invoiceTable').DataTable().row('.invoice' + response.data.id)
                                    .remove()
                                    .draw();
                            } else {
                                Swal.fire("Error!", "Can't delete invoice", "error");
                            }
                        }
                    });

                }
            })


        }
        //end

        // item onchange function
        var price;
        var j;
        $(document).on('change', '#item', function() {
            j = $(this).attr('data-id');
            var id = $(this).val();
            if (id == '') {
                $(".vat_amount").val(0);
                $(".vat").val(0);
                $(".grand_total").val(0);
                $(".sub_total").val(0);
                var qty = $('.item_quantity' + j).val(0);
                $('.item_quantity' + j).prop('disabled', true);
                $('.item_price' + j).val(0);
                $('.unit_price' + j).val(0);
                $('.default_price' + j).val(0);

                $("#edit_vat_amount").val(0);
                $("#edit_vat").val(0);
                $('#edit_discount_amount').val(0)
                $('#edit_discount').val(0)
                $("#edit_grand_total").val(0);
                $("#edit_sub_total").val(0);
                var qty = $('.edit_item_quantity' + j).val(0);
                $('.edit_item_quantity' + j).prop('disabled', true);
                $('.edit_item_price' + j).val(0);
                $('.edit_unit_price' + j).val(0);
                $('.edit_default_price' + j).val(0);
            } else {
                $('.item_quantity' + j).prop('disabled', false);
                $('.edit_item_quantity' + j).prop('disabled', false);
                $.ajax({
                    url: config.routes.getItemPrice,
                    method: "POST",
                    data: {
                        id: id,
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    dataType: "json",
                    success: function(response) {
                        if (response.success == true) {
                            $('.edit_item_quantity' + j).val(0)
                            // $('#edit_sub_total').val(0)
                            // $('.sub_total').val(0)
                            // $('#edit_vat').val(0)
                            // $('.vat').val(0)
                            // $('#edit_vat_amount').val(0)
                            // $('.vat_amount').val(0)
                            // $('#edit_discount').val(0)
                            // $('.discount').val(0)
                            // $('#edit_discount_amount').val(0)
                            // $('.discount_amount').val(0)
                            // $('#edit_grand_total').val(0)
                            // $('.grand_total').val(0)
                            price = response.data.price;
                            $('.item_quantity' + j).val(0);
                            // $('.unit_price' + j).val('৳ ' + currencyFormat(price));
                            $('#test_price' + j).val('৳ ' + bdCurrencyFormat(price));
                            // $('.unit_price' + j).val(price);
                            // $('.default_price' + j).val(price);
                            $('.default_price' + j).val('৳ ' + bdCurrencyFormat(price));
                            $('.item_price' + j).val(0);
                            $('.edit_default_price' + j).val('৳ ' + bdCurrencyFormat(price));
                            $('.edit_unit_price' + j).val('৳ ' + bdCurrencyFormat(price));
                            $('.edit_item_price' + j).val(0);

                        }
                    } //success end
                }); //ajax end

            }

        });

        function two_decimal(data) {
            var data = parseFloat(data);
            // alert(data);
            return data.toFixed(2);
        }

        function format_value(val) {
            var number = Number(val.replace(/[^0-9\.-]+/g, ""));
            var val = parseFloat(number);
            return val;
        }
        // set price by quantity
        // var total= 0;
        $(document).on("change keyup", ".quantity", function() {
            var data_id = $(this).attr('data-id');
            //    alert(data_id);
            var quantity = $(this).val();
            if (quantity < 0) {
                $(this).val(0);
                $('.item_price' + data_id).val(0);
                // alert('hello');
            } else {
                var unit_price = $('.unit_price' + data_id).val();
                var cleanNumber = $('.unit_price' + data_id).val().split(",").join("");
                var str = cleanNumber.replace("৳", "")

                var new_price = two_decimal(quantity * str);

                $('.item_price' + data_id).val('৳ ' + bdCurrencyFormat(new_price));
                $('#price' + data_id).val(new_price);
                // $('.total').find('.sub_total').val(new_price);

                var total = 0;
                $(".price").each(function() {
                    var cleanNumber2 = $(this).val();
                    var number = Number(cleanNumber2.replace(/[^0-9\.-]+/g, ""));
                    total += parseFloat(number || 0);
                });

                var new_sub_total = two_decimal(total);
                $(".sub_total").val('৳ ' + bdCurrencyFormat(new_sub_total));


                if (total == 0) {
                    $(".vat").val(total);
                    $(".vat_amount").val(total);
                    $(".grand_total").val(total);
                } else {
                    var vat = $('#vat_row').find(".vat").val();
                    // console.log(vat);
                    if (vat == 0) {
                        $(".vat").val(15);
                    } else {
                        $(".vat").val(vat);
                    }
                    var discount = format_value($(".discount").val());
                    var discount_amount = format_value($(".discount_amount").val());
                    // var formated_discount_amount = Number(discount_amount.replace(/[^0-9\.-]+/g, ""));

                    var vat_amount = (total * vat) / 100;
                    var formated_vat_amount = two_decimal(vat_amount);

                    // var p = vat_amount.toFixed(2);
                    // $(".vat_amount").val(vat_amount);
                    var check_vat_amount = bdCurrencyFormat(formated_vat_amount);
                    // console.log(formated_vat_amount);
                    // $(".vat_amount").val(4000);
                    $(".vat_amount").val('৳ ' + check_vat_amount);

                    if (discount_amount == 0) {
                        var grand_total = total + vat_amount;

                        var formated_grand_total = two_decimal(grand_total);
                        $(".grand_total").val('৳ ' + bdCurrencyFormat(formated_grand_total));
                    } else {

                        var new_total = two_decimal(total + vat_amount);

                        // console.log(new_total);
                        var new_discount_amount = (new_total * discount) / 100;
                        var formated_discount_amount = two_decimal(new_discount_amount);
                        var grand_total = new_total - formated_discount_amount;
                        var formated_grand_total = two_decimal(grand_total);
                        $('.discount_amount').val('৳ ' + bdCurrencyFormat(formated_discount_amount));
                        $(".grand_total").val('৳ ' + bdCurrencyFormat(formated_grand_total));
                    }

                }
            }


        });
        // set price by unit price change 
        $(document).on("change keyup", ".unit_price", function() {
            var data_id = $(this).attr('data-id');
            var quantity = format_value($('.item_quantity' + data_id).val());
            if (quantity < 0) {
                $(this).val(0);
                $('.item_price' + data_id).val(0);
                // alert('hello');
            } else {
                var unit_price = format_value($('.unit_price' + data_id).val());
                // var cleanNumber = $('.unit_price' + data_id).val().split(",").join("");
                // var str = cleanNumber.replace("৳", "")
                var new_price = two_decimal(quantity * unit_price);

                $('.item_price' + data_id).val('৳ ' + bdCurrencyFormat(new_price));

                var total = 0;
                $(".price").each(function() {
                    var price = format_value($(this).val());
                    total += parseFloat(price || 0)
                });
                $(".sub_total").val('৳ ' + bdCurrencyFormat(two_decimal(total)));



                if (total == 0) {
                    $(".vat").val(total);
                    $(".vat_amount").val(total);
                    $(".grand_total").val(total);
                } else {
                    var vat = $(".vat").val();
                    if (vat == 0) {
                        $(".vat").val(15);
                    } else {
                        $(".vat").val(vat);
                    }


                    var discount = format_value($(".discount").val());
                    var discount_amount = format_value($(".discount_amount").val());
                    var vat_amount = (total * vat) / 100;
                    var formated_vat_amount = two_decimal(vat_amount);

                    var check_vat_amount = bdCurrencyFormat(formated_vat_amount);
                    $(".vat_amount").val('৳ ' + check_vat_amount);

                    if (discount_amount == 0) {
                        var grand_total = total + vat_amount;
                        var formated_grand_total = two_decimal(grand_total);
                        $(".grand_total").val('৳ ' + bdCurrencyFormat(formated_grand_total));
                    } else {
                        var new_total = two_decimal(total + vat_amount);
                        var new_discount_amount = (new_total * discount) / 100;
                        var grand_total = new_total - discount_amount;
                        var formated_grand_total = two_decimal(grand_total);
                        var formated_discount_amount = two_decimal(new_discount_amount);
                        $('.discount_amount').val('৳ ' + bdCurrencyFormat(formated_discount_amount));
                        $(".grand_total").val('৳ ' + bdCurrencyFormat(formated_grand_total));
                    }

                }
            }


        });
        $(document).on("change keyup blur", ".edit_unit_price", function() {
            var data_id = $(this).attr('data-id');
            var quantity = $('.edit_item_quantity' + data_id).val();
            // console.log(quantity);
            if (quantity < 0) {
                $(this).val(0);
                $('.edit_item_price' + data_id).val(0);
                // alert('hello');
            } else {
                var unit_price = format_value($('#edit_unit_price' + data_id).val());
                var new_price = two_decimal(quantity * unit_price);

                $('.edit_item_price' + data_id).val('৳ ' + bdCurrencyFormat(new_price));
                // $('.total').find('.sub_total').val(new_price);

                var total = 0;
                $(".price").each(function() {
                    var value = format_value($(this).val());
                    total += parseFloat(value || 0);
                });
                console.log(total);
                $(".sub_total").val('৳ ' + bdCurrencyFormat(two_decimal(total)));


                if (total == 0) {
                    $("#edit_vat").val(total);
                    $("#edit_vat_amount").val(total);
                    $("#edit_grand_total").val(total);
                } else {
                    var vat = $("#edit_vat").val();
                    if (vat == 0) {
                        $("#edit_vat").val(15);
                    } else {
                        $("#edit_vat").val(vat);
                    }


                    var discount = format_value($("#edit_discount").val());
                    var discount_amount = format_value($("#edit_discount_amount").val());
                    var vat_amount = (total * vat) / 100;
                    $("#edit_vat_amount").val('৳ ' + bdCurrencyFormat(two_decimal(vat_amount)));

                    if (discount_amount == 0) {
                        var grand_total = two_decimal(total + vat_amount);
                        $("#edit_grand_total").val('৳ ' + bdCurrencyFormat(grand_total));
                    } else {
                        var new_total = two_decimal(total + vat_amount);
                        var new_discount_amount = (new_total * discount) / 100;
                        var formated_discount_amount = two_decimal(new_discount_amount);
                        var grand_total = two_decimal(new_total - discount_amount);
                        $('#edit_discount_amount').val('৳ ' + bdCurrencyFormat(formated_discount_amount));
                        $("#edit_grand_total").val('৳ ' + bdCurrencyFormat(grand_total));
                    }

                }
            }


        });


        // edit modal quantity change 
        $(document).on("change keyup blur", ".edit_quantity", function() {
            var data_id = $(this).attr('data-id');

            var quantity = $(this).val();
            // console.log(quantity);
            if (quantity < 0) {

                // alert('sadasd');
                // $(this).val(prev);
                // $('.item_price' + data_id).val(0);
                // alert('hello');
            } else {
                var price = $('#edit_unit_price' + data_id).val();
                var formated_price = format_value(price);
                var new_price = two_decimal(quantity * formated_price);

                $('.edit_item_price' + data_id).val('৳ ' + bdCurrencyFormat(new_price));
                // $('.total').find('.sub_total').val(new_price);

                var total = 0;
                $(".price").each(function() {
                    var value = format_value($(this).val());
                    total += parseFloat(value || 0);
                });
                // console.log(total);

                $(".sub_total").val('৳ ' + bdCurrencyFormat(total));


                if (total == 0) {
                    $("#edit_vat").val(total);
                    $("#edit_vat_amount").val(total);
                    $("#edit_grand_total").val(total);
                } else {
                    var vat = $("#edit_vat").val();
                    var formated_vat = format_value(vat);
                    if (formated_vat == 0) {
                        $("#edit_vat").val(15);
                    } else {
                        $("#edit_vat").val(formated_vat);
                    }

                    var discount = $("#edit_discount").val();
                    var formated_discount = format_value(discount);
                    var discount_amount = $("#edit_discount_amount").val();
                    var formated_discount_amount = format_value(discount_amount);
                    var vat_amount = (total * vat) / 100;
                    var formated_vat_amount = two_decimal(vat_amount);

                    $(".vat_amount").val('৳ ' + bdCurrencyFormat(formated_vat_amount));

                    if (formated_discount_amount == 0) {
                        var grand_total = two_decimal(total + vat_amount);
                        $("#edit_grand_total").val('৳ ' + bdCurrencyFormat(grand_total));
                    } else {
                        var new_total = two_decimal(total + vat_amount);
                        var new_discount_amount = (new_total * discount) / 100;
                        var new_formated_discount_amount = two_decimal(new_discount_amount);

                        var grand_total = two_decimal(new_total - new_formated_discount_amount);
                        $('#edit_discount_amount').val('৳ ' + bdCurrencyFormat(new_formated_discount_amount));
                        $("#edit_grand_total").val('৳ ' + bdCurrencyFormat(grand_total));
                    }
                }
            }


        });

        function itemChange() {
            // var total = 0;
            // $(".price").each(function() {
            //     total += parseFloat($(this).val() || 0);
            // });
            // console.log($('.price').val());
            $(".sub_total").val(0);
            $(".vat_amount").val(0);
            $(".vat").val(0);
            $(".discount_amount").val(0);
            $(".discount").val(0);
            $(".grand_total").val(0);

            // if(total == 0){
            //         $(".vat").val(0);
            //         $(".vat_amount").val(0);
            //         $(".grand_total").val(0);                  
            //     }else{
            //         $(".vat").val(15);
            //         var vat = $(".vat").val();
            //         var vat_amount = (total * vat) /100;
            //         var grand_total = total + vat_amount;
            //         $(".vat_amount").val(vat_amount);
            //         $(".grand_total").val(grand_total);   
            //     }
        }

        // $(document).on("change keyup blur", ".vat", function(){
        //     var total = 0;
        //     $(".price").each(function() {
        //         total += parseFloat($(this).val() || 0);
        //     });
        //     var vat = $(this).val();
        //     console.log(vat);
        //     var vat_amount = (total * vat) /100;
        //     var grand_total = total + vat_amount;
        //     $(".vat_amount").val(vat_amount);
        //     $(".grand_total").val(grand_total); 
        // });

        // vat change function
        $(document).ready(function() {
            $(".vat").on("input", function() {
                var sub_total = $(".sub_total").val().split(",").join("");
                var formated_sub_total = parseFloat(sub_total.replace("৳", ""));
                var discount = parseFloat($('.discount').val());
                var discount_amount = $('.discount_amount').val().split(",").join("");
                var formated_discount_amount = parseFloat(discount_amount.replace("৳", ""));
                var vat = $(this).val();
                var vat_amount = (formated_sub_total * vat) / 100;
                var formated_vat_amount = two_decimal(vat_amount)
                $(".vat_amount").val('৳ ' + bdCurrencyFormat(formated_vat_amount));


                if (formated_discount_amount == 0) {
                    var grand_total = two_decimal(formated_sub_total + vat_amount);
                    $(".grand_total").val('৳ ' + bdCurrencyFormat(grand_total));
                } else {
                    var new_total = two_decimal(formated_sub_total + vat_amount);
                    var new_discount_amount = (new_total * discount) / 100;
                    var new_formated_discount_amount = two_decimal(new_discount_amount);
                    var grand_total = two_decimal(new_total - new_formated_discount_amount);
                    $('.discount_amount').val('৳ ' + bdCurrencyFormat(new_formated_discount_amount));
                    $(".grand_total").val('৳ ' + bdCurrencyFormat(grand_total));
                }


            });
        });

        function sum_value(num1, num2) {
            var num1 = parseFloat(num1);
            var num2 = parseFloat(num2);
            var result = num1 + num2;
            return result;
        }
        // edit modal vat change function
        $(document).ready(function() {
            $("#edit_vat").on("input", function() {
                var sub_total = format_value($("#edit_sub_total").val());
                var discount = format_value($('#edit_discount').val());
                var discount_amount = format_value($('#edit_discount_amount').val());
                var vat = $(this).val();
                var vat_amount = (sub_total * vat) / 100;
                var formated_vat_amount = two_decimal(vat_amount)

                console.log((sub_total, vat_amount));
                // console.log('vat_amount =',vat_amount);
                $("#edit_vat_amount").val('৳ ' + bdCurrencyFormat(formated_vat_amount));


                if (discount == 0) {
                    var grand_total = sum_value(sub_total, vat_amount);
                    $("#edit_grand_total").val('৳ ' + bdCurrencyFormat(grand_total));
                } else {
                    var new_total = sum_value(sub_total, vat_amount);
                    var new_discount_amount = (new_total * discount) / 100;
                    var new_formated_discount_amount = two_decimal(new_discount_amount);
                    var grand_total = two_decimal(new_total - new_discount_amount);
                    $('#edit_discount_amount').val('৳ ' + bdCurrencyFormat(new_formated_discount_amount));
                    $("#edit_grand_total").val('৳ ' + bdCurrencyFormat(grand_total));
                }


            });
        });
        // discount change function
        $(document).ready(function() {
            $(".discount").on("input", function() {
                var discount = $(this).val();
                var vat_amount = $(".vat_amount").val().split(",").join("");
                var sub_total = $(".sub_total").val().split(",").join("");
                var formated_sub_total = parseFloat(sub_total.replace("৳", ""));
                var formated_vat_amount = parseFloat(vat_amount.replace("৳", ""));
                var total = two_decimal(formated_sub_total + formated_vat_amount);
                if (total != 0) {
                    var discount_amount = two_decimal((total * discount) / 100);
                    $(".discount_amount").val('৳ ' + bdCurrencyFormat(discount_amount));
                    var new_total_val = two_decimal(total - discount_amount);
                    $(".grand_total").val('৳ ' + bdCurrencyFormat(new_total_val));

                }

            });
        });
        // edit modal discount change function
        $(document).ready(function() {
            $("#edit_discount").on("input", function() {
                var discount = format_value($(this).val());
                var vat_amount = format_value($("#edit_vat_amount").val());
                var sub_total = format_value($("#edit_sub_total").val());

                var total = sum_value(sub_total, vat_amount);
                if (total != 0) {
                    var discount_amount = (total * discount) / 100;
                    $("#edit_discount_amount").val('৳ ' + bdCurrencyFormat(two_decimal(discount_amount)));
                    var new_total_val = two_decimal(total - discount_amount);
                    $("#edit_grand_total").val('৳ ' + bdCurrencyFormat(new_total_val));

                }

            });
        });

        // add more item by plus button click
        var i = 0;
        $(document).on('click', '.item_plus_icon', function() {
            var get_quantity = $('.item_row').find('.item_quantity' + i).val();


            if (get_quantity === '') {
                // alert(get_quantity);
                // console.log('value:',i)
                // $('.product_row').find('.error'+i).after('<p class="text-danger error_msg">Please select an item</p>')
                $('.error_msg' + i).addClass('mt-1').text('This field is required');
                $('.error_msg' + i).show();
                $('.close_btn').find('.fa-window-close').addClass('cross_icon');
            } else if (get_quantity == 0) {
                // console.log(get_quantity);
                $('.qty_error_msg' + i).addClass('mt-1').text('This field is required');
                $('.error_msg' + i).show();
                $('.close_btn').find('.fa-window-close').addClass('cross_icon');
            } else {
                $('.qty_error_msg' + i).hide();
                $('.error_msg' + i).hide();
                ++i;

                $('.error_msg').hide();
                $(".close_btn").show();

                $('.float-right').find('.fa-plus-square').removeClass('plus_icon');
                $('.item_row:last').after(
                    `
                <div class="form-row item_row data${i}">
                            <div class="col-xl-3 col-md-12 mb-3">

                                <div class="ms-form-group">
                                    <label for="validationCustom10">Select Item</label>
                                    <select class="form-control" name="item[${i}][item_id]"  class="form-control item_id item${i}" id="item" data-id="${i}">
                                        <option value="">Select Item</option>
                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name ?? 'not found'); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>

                                    <p class="text-danger error_msg${i} "></p>
                                   
                                </div>

                            </div>
                            <div class="col-xl-2 col-md-12 mb-3">
                                <div class="ms-form-group">
                                    <label for="validationCustom10">Quantity</label>
                                    <input type="number" name="item[${i}][quantity]" class="form-control quantity item_quantity${i}" disabled
                                         placeholder="Quantity" data-id="${i}">
                                     <p class="text-danger error_msg${i} qty_error_msg${i}"></p>
                                   
                                   
                                </div>
                            </div>
                            <div class="col-xl-2 col-md-12 mb-3">
                                <div class="ms-form-group" id="unit_price_div">
                                    <label for="validationCustom10">Unit Price (Default)</label>
                                    <input type="text"  class="form-control default_price${i}"
                                         placeholder="Unit Price" data-id="${i}" readonly>

                                        <p class="text-danger error_msg${i} "></p>
                                   
                                </div>
                            </div>
                            <div class="col-xl-2 col-md-12 ">
                                <div class="ms-form-group " >
                                    <label for="validationCustom10">Unit Price</label>
                                    <input type="text" name="item[${i}][unit_price]" class="form-control unit_price unit_price${i}" id="test_price${i}"
                                        placeholder="Price" data-id="${i}">
                                    <p class="text-danger error_msg0 "></p>
                                </div>
                            </div>

                            <div class="col-xl-2 col-md-12 mb-3">
                                <div class="ms-form-group">
                                    <label for="validationCustom10"> Price</label>
                                    <input type="hidden" class="hidden_price" id="price${i}">
                                    <input type="text" name="item[${i}][price]" class="form-control price item_price${i}"
                                         placeholder="Price" data-id="${i}" readonly>
                                    <p class="text-danger error_msg0 "></p>
                                    
                                </div>
                            </div>
                            
                            <div class="col-xl-1 col-md-12">
                                <span class="float-right close_btn remove_row${i}" onclick="remove(${i})"><i class="fa fa-window-close"></i></span>
                            </div>

                        </div>
                `


                );

            }

        });

        // remove row 
        function remove(data) {
            var row_length = $('.item_row ').length;
            if (row_length == 2) {
                $(".close_btn").hide();
            }
            $(".data" + data).remove();
            // $('.float-right').find('.fa-plus-square').addClass('plus_icon');
            var total = 0;
            $(".price").each(function() {
                var cleanNumber2 = $(this).val();
                var number = Number(cleanNumber2.replace(/[^0-9\.-]+/g, ""));
                total += parseFloat(number || 0);
            });
            var formated_total = two_decimal(total);
            // console.log();
            $(".sub_total").val(formated_total);
            var vat = format_value($(".vat").val());
            var discount = format_value($(".discount").val());
            var vat_amount = (total * vat) / 100;
            var formated_vat_amount = two_decimal(vat_amount);

            var discount_amount = (total * discount) / 100;


            var grand_total = two_decimal(formated_total + formated_vat_amount);
            // $("#edit_grand_total").val('৳ '+bdCurrencyFormat(grand_total));


            $(".vat_amount").val('৳ ' + bdCurrencyFormat(formated_vat_amount));
            $(".discount_amount").val('৳ ' + bdCurrencyFormat(two_decimal(discount_amount)));
            $(".grand_total").val('৳ ' + bdCurrencyFormat(grand_total));
        }
        // remove row from edit modal
        function removeRow(data) {
            var row_length = $('.item_row_edit ').length;
            if (row_length == 2) {
                $(".close_btn").hide();
            }
            $(".data" + data).remove();
            var total = 0;
            $(".price").each(function() {
                var cleanNumber2 = $(this).val();
                var number = Number(cleanNumber2.replace(/[^0-9\.-]+/g, ""));
                total += parseFloat(number || 0);
            });
            // console.log();
            var formated_total = two_decimal(total);
            // console.log(formated_total);
            // $(".grand_total").val('৳ '+bdCurrencyFormat(formated_grand_total));

            $("#edit_sub_total").val('৳ ' + bdCurrencyFormat(formated_total));
            var vat = format_value($("#edit_vat").val());
            var discount = format_value($("#edit_discount").val());
            var vat_amount = (total * vat) / 100;
            var formated_vat_amount = two_decimal(vat_amount);
            $("#edit_vat_amount").val('৳ ' + bdCurrencyFormat(formated_vat_amount));

            if (discount == 0) {
                var grand_total = two_decimal(formated_total + formated_vat_amount);
                $("#edit_grand_total").val('৳ ' + bdCurrencyFormat(grand_total));
                $("#edit_discount").val(discount);
            } else {
                var grand_total = two_decimal(formated_total + formated_vat_amount);
                var discount_amount = (grand_total * discount) / 100;
                var new_total = two_decimal(grand_total - discount_amount);
                $("#edit_grand_total").val('৳ ' + bdCurrencyFormat(new_total));
                $("#edit_discount").val(discount);
                $("#edit_discount_amount").val('৳ ' + bdCurrencyFormat(discount_amount));
            }
        }

        $.validator.addClassRules("item_id", {
            required: true,
        });
        $.validator.addClassRules("quantity", {
            required: true,
        });
        $.validator.addClassRules("price", {
            required: true,
        });


        // var k = $('.item_row_edit ').length;

        $(document).on('click', '.edit_item_plus_icon', function() {
            var i = $('.item_row_edit ').length - 1;
            var get_quantity = $('.item_row_edit').find('.edit_item_quantity' + i).val();

            if (get_quantity === '') {
                // alert(get_quantity);
                // console.log('value:',i)
                // $('.product_row').find('.error'+i).after('<p class="text-danger error_msg">Please select an item</p>')
                $('.error_msg' + i).addClass('mt-1').text('This field is required');
                $('.error_msg' + i).show();
                $('.close_btn').find('.fa-window-close').addClass('cross_icon');
            } else if (get_quantity == 0) {

                $('.qty_error_msg' + i).addClass('mt-1').text('This field is required');
                $('.error_msg' + i).show();
                $('.close_btn').find('.fa-window-close').addClass('cross_icon');
            } else {
                $('.qty_error_msg' + i).hide();
                $('.error_msg' + i).hide();
                ++i;

                $('.error_msg').hide();
                $(".close_btn").show();

                $('.float-right').find('.fa-plus-square').removeClass('plus_icon');
                $('.item_row_edit:last').after(
                    `
                    <div class="form-row item_row_edit data${i}" >
  
                            <div class="col-xl-3 col-md-12 mb-3">

                                <div class="ms-form-group">
                                    <label for="validationCustom10">Select Item</label>
                                    <select class="form-control" name="item[${i}][item_id]" 
                                        class="form-control item_id item${i}" id="item" data-id="${i}">
                                        <option value="">Select Item</option>
                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>">
                                                <?php echo e($item->name ?? 'not found'); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                    <p class="text-danger error_msg${i} "></p>
                                   
                                </div>

                            </div>
                            <div class="col-xl-2 col-md-12 mb-3">
                                <div class="ms-form-group">
                                    <label for="validationCustom10">Quantity</label>
                                    <input type="number" name="item[${i}][quantity]"
                                        class="form-control edit_quantity edit_item_quantity${i}" placeholder="Quantity"
                                        data-id="${i}" >
                                    <p class="text-danger error_msg0 qty_error_msg${i}"></p>
                                   
                                </div>
                            </div>
                            <div class="col-xl-2 col-md-12 mb-3">
                                <div class="ms-form-group" id="unit_price_div">
                                    <label for="validationCustom10">Unit Price (Default)</label>
                                    <input type="text" name="unit_price" class="form-control edit_unit_price${i}" 
                                        placeholder="Unit Price" data-id="${i}" readonly>
                                    <p class="text-danger error_msg${i}"></p>
                                   
                                </div>
                            </div>
                            <div class="col-xl-2 col-md-12 mb-3">
                                <div class="ms-form-group">
                                    <label for="validationCustom10">Unit Price</label>
                                    <input type="text" name="item[${i}][unit_price]" class="form-control edit_unit_price edit_unit_price${i}" id="edit_unit_price${i}"
                                        placeholder="Unit Price" data-id="${i}">
                                    <p class="text-danger error_msg${i}"></p>
                                   
                                </div>
                            </div>
                            <div class="col-xl-2 col-md-12 mb-3">
                                <div class="ms-form-group">
                                    <label for="validationCustom10"> Price</label>
                                    <input type="text" name="item[${i}][price]" class="form-control price edit_item_price${i}"
                                        placeholder="Price" data-id="${i}" readonly>
                                    <p class="text-danger error_msg${i} "></p>


                                </div>
                            </div>
                            <div class="col-xl-1 col-md-12 mb-3">
                                <span class="float-right close_btn remove_row${i}" onclick="removeRow(${i})">
                                    <i class="fa fa-window-close"></i>
                                </span>
                            </div>

                        </div>
                `


                );

            }

        });

        // approve status update function 
        function approveInvoice(id) {

            Swal.fire({
                title: 'Are you sure to update?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, update it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        type: "POST",
                        url: config.routes.update_approve_status,
                        data: {
                            id: id,
                            _token: "<?php echo e(csrf_token()); ?>"
                        },
                        dataType: 'JSON',
                        success: function(response) {
                            if (response.success === true) {
                                toastMixin.fire({
                                    icon: 'success',
                                    animation: true,
                                    title: "" + response.data.message + ""
                                });
                                // if(response.data.status == 1){
                                //     `<input type="checkbox" id="switch${response.data.id}" switch="success" checked 
                            //         onclick="approveInvoice(${response.data.id})">
                            //      <label for="switch${response.data.id}" data-on-label data-off-label></label>`
                                // }else{

                                // }
                            } else {
                                Swal.fire("Error!", "Can't delete invoice", "error");
                            }
                        }
                    });

                } else {
                    var approve_checkbox = $('#switch' + id);
                    if ($(approve_checkbox).prop("checked") == true) {
                        $(approve_checkbox).prop('checked', false);
                    } else {
                        $(approve_checkbox).prop('checked', true);
                    }
                }
            });
        }

        // invouce approve 
        function approveQuotation(id) {
            $.ajax({
                type: "POST",
                url: config.routes.update_approve_status,
                data: {
                    id: id,
                    _token: "<?php echo e(csrf_token()); ?>"
                },
                dataType: 'JSON',
                success: function(response) {
                    if (response.success === true) {
                        toastMixin.fire({
                            icon: 'success',
                            animation: true,
                            title: "" + response.data.message + ""
                        });
                        $('.status' + response.data.id).html(response.data.approve_status);
                        if (response.data.unapproved_invoice == 0) {
                            $('.invoice_ul').find('.unapproved_invoices').html('');
                            // console.log(response.data.unapproved_invoice);
                        } else {
                            $('.invoice_ul').find('.unapproved_invoices').html(response.data
                                .unapproved_invoice);
                        }
                        if (response.data.status == 1) {
                            $('.approve_icon').empty();

                            $('.approve_button').html(
                                    'Approved <span class="approve_icon"><i class="fa fa-check"></i></span>')
                                .addClass('disabled');
                        } else {
                            $('.approve_button').html('Approve');
                            // $('.approve_button').val('approve');
                            // $('.approve_button').prop('disabled',false);

                        }
                    } else {
                        Swal.fire("Error!", "Something went wrong", "error");
                    }
                }
            });
        } // end

        // show manager select box 
        $(document).on('click', '.assign_manager_checkbox', function() {
            if ($(this).prop("checked") == true) {
                $('.manager_selcet_box').show();
                $('.select_manager').prop('disabled', false);
            } else {
                $('.manager_selcet_box').hide();
                $('.select_manager').prop('disabled', true);
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_ant\quotation_builder\resources\views/admin/invoice_latest.blade.php ENDPATH**/ ?>