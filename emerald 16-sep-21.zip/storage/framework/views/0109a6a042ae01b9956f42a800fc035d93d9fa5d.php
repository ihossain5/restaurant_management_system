<?php
use App\Http\Controllers\InvoiceController;
$items = InvoiceController::countUnapproveInvoices();
$data = InvoiceController::countRedoInvoices();
?>
<!-- ========== Left Sidebar Start ========== -->
<div class="left side-menu">

    <!-- LOGO -->
    <div class="topbar-left">
        <div class="">
            <!--<a href="index.html" class="logo text-center">Fonik</a>-->
            <a href="<?php echo e(route('dashboard')); ?>" class="logo">
                <h6>Quotation Builder</h6>
                
            </a>
        </div>
        

    </div>

    <div class="sidebar-inner slimscrollleft">
        <div id="sidebar-menu">
            <ul>
                <div class="">
                    <div class="card sidebar_user_card m-b-20">
                        <div class="card-body">

                            <div class="media justify-content-center">
                                <?php if(Auth::user()->image == null): ?>
                                    <img src="<?php echo e(asset('images/default.png')); ?>" class="left_sidebar_image"
                                        alt="user-profle">
                                <?php else: ?>
                                    <img class="d-flex mr-2 rounded-circle thumb-lg"
                                        src="<?php echo e(asset('images/' . Auth::user()->image)); ?>"
                                        alt="Generic placeholder image">
                                <?php endif; ?>
                            </div>
                            <div>
                                <h6 class="text-center user_name"><?php echo e(Auth::user()->name); ?></h6>
                            </div>

                        </div>
                    </div>

                </div>
                <div class="text-center">
                    <?php if(Auth::user()->email == 'sheehanvy@gmail.com' && Auth::user()->is_manager == 1): ?>
                        <button class="btn btn-success btn-sm mr-2 btn_disabled">Super Admin </button>
                        <button class="btn btn-success btn-sm btn_disabled"> Manager </button>
                    <?php elseif((Auth::user()->is_admin == 1 && Auth::user()->is_manager == 1)): ?>
                        <button class="btn btn-success btn-sm mr-2 btn_disabled"> Admin </button>
                        <button class="btn btn-success btn-sm btn_disabled"> Manager </button>
                    <?php else: ?>
                        <button class="btn btn-success btn-sm btn_disabled">
                            <?php echo e(Auth::user()->email == 'sheehanvy@gmail.com' ? 'Super Admin' : (Auth::user()->is_admin == 1 ? 'Admin' : (Auth::user()->is_manager == 1 ? 'Manager' : 'Employee'))); ?>

                        </button>
                    <?php endif; ?>


                </div>


                <li class="menu-title">Main</li>

                <li>
                    <a href="<?php echo e(route('dashboard')); ?>" class="waves-effect"><i
                            class="dripicons-device-desktop"></i><span>
                            Dashboard </span></a>
                </li>
                <?php if(Auth::user()->email == 'sheehanvy@gmail.com' || Auth::user()->is_admin == 1 || Auth::user()->is_manager == 1): ?>
                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-suitcase"></i><span>
                                Item Management <span class="float-right"><i class="mdi mdi-chevron-right"></i></span>
                            </span></a>
                        <ul class="list-unstyled">
                            <li>
                                <a href="<?php echo e(route('category.index')); ?>" class="waves-effect">
                                    <i class="dripicons-calendar"></i>
                                    <span> Categories </span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('item.index')); ?>" class="waves-effect">
                                    <i class="dripicons-calendar"></i>
                                    <span> Items </span>
                                </a>
                            </li>

                        </ul>
                    </li>



                    <li>
                        <a href="<?php echo e(route('other.info.index')); ?>" class="waves-effect">
                            <i class="dripicons-calendar"></i>
                            <span> Quotation Info </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('client.index')); ?>" class="waves-effect">
                            <i class="dripicons-calendar"></i>
                            <span> Client Management </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('employee.index')); ?>" class="waves-effect">
                            <i class="dripicons-calendar"></i>
                            <span> User Management </span>
                        </a>
                    </li>
                <?php endif; ?>
                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-suitcase"></i><span>
                            Invoice Management <span class="float-right"><i class="mdi mdi-chevron-right"></i></span>
                        </span></a>
                    <ul class="list-unstyled invoice_ul">
                        <li>
                            <a href="<?php echo e(route('invoice.index')); ?>" class="waves-effect">
                                <i class="dripicons-calendar"></i>
                                <span> All Invoices </span>
                            </a>
                        </li>
                        <?php if(Auth::user()->email == 'sheehanvy@gmail.com' || Auth::user()->is_admin == 1): ?>
                            <li>
                                <a href="<?php echo e(route('invoice.unapproved')); ?>" class="waves-effect">
                                    <i class="dripicons-calendar"></i>
                                    <span> Waiting for approval <span
                                            class="badge badge-warning unapproved_invoices"><?php echo e($items == 0 ? '' : $items); ?></span></span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('invoice.approved')); ?>" class="waves-effect">
                                    <i class="dripicons-calendar"></i>
                                    <span> Requested for redo <span
                                            class="badge badge-warning redo_invoices"><?php echo e($data == 0 ? '' : $data); ?></span></span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </li>
                



            </ul>
        </div>
        <div class="clearfix"></div>
    </div> <!-- end sidebarinner -->
</div>
<!-- Left Sidebar End -->
<?php /**PATH C:\xampp\htdocs\laravel_ant\quotation_builder\resources\views/layouts/admin/left_sidebar.blade.php ENDPATH**/ ?>